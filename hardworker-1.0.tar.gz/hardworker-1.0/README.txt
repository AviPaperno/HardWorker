Description
===========

It is Home Work for Yandex. System for run hard tasks.